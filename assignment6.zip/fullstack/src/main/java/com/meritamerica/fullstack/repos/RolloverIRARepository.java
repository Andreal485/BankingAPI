/*package com.meritamerica.fullstack.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.meritamerica.fullstack.models.RolloverIRA;

public interface RolloverIRARepository extends JpaRepository<RolloverIRA, Long> {

	RolloverIRA findById(long id);

	List<RolloverIRA> findAll();
}
*/