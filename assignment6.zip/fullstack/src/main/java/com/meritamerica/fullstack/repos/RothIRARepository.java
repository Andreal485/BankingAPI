/*package com.meritamerica.fullstack.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.meritamerica.fullstack.models.RothIRA;

public interface RothIRARepository extends JpaRepository<RothIRA, Long> {

	RothIRA findById(long id);

	List<RothIRA> findAll();
}
*/